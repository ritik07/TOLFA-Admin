import React from 'react'

const Refund = () => {
  return (
    <div>
      Cancellation & Refund Policy

      Last updated on Feb 19th 2023

      No cancellations & Refunds are entertained
    </div>
  )
}

export default Refund