import React from "react";
import Address from "../../component/Address";

const Purchase = () => {
  return (
    <div>
      <Address />
    </div>
  );
};

export default Purchase;
