import React from 'react'

const ContactUs = () => {
  return (
    <div>
      Contact us

      Last updated on Feb 19th 2023

      You may contact us using the information below:

      Merchant Legal entity name: Doggiesthan
      Registered Address: DOGGIESTHAN - The Pet State. 53/91 Saryu Marg, Opposite JKJ Jewellers ,Madhyam Marg, near V.T. Road, Mansarovar Jaipur Jaipur RAJASTHAN 302020
      Telephone No: 8169745550
      E-Mail ID: doggiesthan@gmail.com
    </div>
  )
}

export default ContactUs