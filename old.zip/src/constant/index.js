// export const BASE_URL = "https://d-server-cny9.onrender.com/api/v1/";
// export const BASE_URL_ASSET = "https://arihantchemical.in/upload-service/uploads";

export const BASE_URL = "http://localhost:5050/api/v1/";
export const BASE_URL_ASSET = "http://localhost:5050";
